﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CodeMonkey.Utils;
using CodeMonkey;
using UnityCore.Data;
using UnityCore.Scene;

public class PF_testBasement : MonoBehaviour {
    public SceneController sceneController;
    private Pathfinding pathfinding;
    public DataPresistence DP;
    int startFloor;
    int startX;
    int startY;
    int endX;
    int endY;
    int changeScene;
    private float speed = 18;
    public List<PathNode> path;
    public List<Vector3> mPath;
    public Transform Obj;
    int i;
   // [SerializeField] private PathfindingVisual pathfindingVisual;

    private void Start()
    {

        changeScene = DP.ChangeScene;
        startFloor = DP.LoadScene;
        int startX = DP.StartX0;
        int startY =  DP.StartY0;
        int endX =  DP.EndX00;
        int endY =  DP.EndY00;
        print(startX + ", " + startY + ",   " + endX + ", " + endY);
        i = 0;
        Log("Start pos: " + startX + ", " + startY);
        Log("End  pos :" +endX+", "+ endY);
        pathfinding = new Pathfinding(11, 45, 0);
        //pathfindingVisual.SetGrid(pathfinding.GetGrid());
        Obj.transform.position = (pathfinding.GetGrid().GetWorldPosition(startX, startY));
        mPath = pathfinding.FindPath(pathfinding.GetGrid().GetWorldPosition(startX, startY), pathfinding.GetGrid().GetWorldPosition(endX, endY));
    }
    private void Update()
    {
       moveIt(Obj);
    if(changeScene > 0 && startFloor == 0)
        {
            checkObjLocation(Obj);
        }
        else
        {
            loadNext(Obj);
        }

    }
    private void moveIt(Transform obj)
    {
       
        print(mPath.Count);
        if (mPath != null)
        {
            if(i < mPath.Count)
            {
                print(i);
                obj.transform.position = Vector3.MoveTowards(obj.position, mPath[i], speed * Time.deltaTime);
                float dist = Vector3.Distance(obj.transform.position, mPath[i]);
                if (dist < 2f)
                {
                    i++;
                }
            }
        }

    }
    private void checkObjLocation(Transform obj)
    {
        float dist = Vector3.Distance(obj.position, mPath[mPath.Count - 1]);
        if(dist < 17f)
        {
            sceneController.Load(SceneType.Benton01);
        }
    }
    private void loadNext(Transform obj)
    {
        float dist = Vector3.Distance(obj.position, mPath[mPath.Count - 1]);
        if (dist < 17f)
        {
            sceneController.Load(SceneType.EndScene);
        }
    }
    private void Log(string _msg)
    {
        Debug.Log("[TestPathFinding] " + _msg);
    }



}