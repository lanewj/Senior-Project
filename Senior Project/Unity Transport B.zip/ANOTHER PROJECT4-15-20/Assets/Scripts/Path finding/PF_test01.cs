﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CodeMonkey.Utils;
using CodeMonkey;
using UnityCore.Data;
using UnityCore.Scene;

public class PF_test01 : MonoBehaviour
{
    public SceneController sceneController;
    private Pathfinding pathfinding;
    public DataPresistence DP;
    int startFloor;
    int startX;
    int startY;
    int endX;
    int endY;
    int changeScene;
    private float speed = 18;
    public List<PathNode> path;
    public List<Vector3> mPath;
    public Transform Obj;
    int i;
    // [SerializeField] private PathfindingVisual pathfindingVisual;

    private void Start()
    {
        changeScene = DP.ChangeScene;
        startFloor = DP.LoadScene;
        int startX = DP.StartX1;
        int startY = DP.StartY1;
        int endX = DP.EndX1;
        int endY =  DP.EndY1;
        i = 0;
        Log("Start X pos: " + startX);
        Log("End Y pos :" + endY);
        pathfinding = new Pathfinding(21, 43, 1);
        //pathfindingVisual.SetGrid(pathfinding.GetGrid());
        Obj.transform.position = (pathfinding.GetGrid().GetWorldPosition(startX, startY));
        mPath = pathfinding.FindPath(pathfinding.GetGrid().GetWorldPosition(startX, startY), pathfinding.GetGrid().GetWorldPosition(endX, endY));
    }
    private void Update()
    {
       moveIt(Obj);
        if (changeScene > 0 && startFloor == 1)
        {
            checkObjLocation(Obj);
        }
        else
        {
            loadNext(Obj);
        }



    }
    private void moveIt(Transform obj)
    {

        //print(mPath.Count);
        if (mPath != null)
        {
            if (i < mPath.Count)
            {
                //print(i);
                obj.transform.position = Vector3.MoveTowards(obj.position, mPath[i], speed * Time.deltaTime);
                float dist = Vector3.Distance(obj.transform.position, mPath[i]);
                if (dist < 2f)
                {
                    i++;
                }
            }
        }

    }
    private void checkObjLocation(Transform obj)
    {
        float dist = Vector3.Distance(obj.position, mPath[mPath.Count - 1]);
        if (dist < 17f)
        {
            sceneController.Load(SceneType.Benton00);
        }
    }
    private void loadNext(Transform obj)
    {
        float dist = Vector3.Distance(obj.position, mPath[mPath.Count - 1]);
        if (dist < 17f)
        {
            sceneController.Load(SceneType.EndScene);
        }
    }
    private void Log(string _msg)
    {
        Debug.Log("[TestPathFinding] " + _msg);
    }



}