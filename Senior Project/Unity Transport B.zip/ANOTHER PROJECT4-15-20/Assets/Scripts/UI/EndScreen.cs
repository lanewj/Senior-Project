﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityCore.Menu;
using UnityCore.Scene;

public class EndScreen : MonoBehaviour
{
    public SceneController sceneController;

    public void nextScene()
    {
        sceneController.Load(SceneType.Menu);
    }
    
}
