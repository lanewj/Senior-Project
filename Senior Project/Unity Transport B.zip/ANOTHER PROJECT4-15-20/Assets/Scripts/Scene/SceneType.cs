﻿
namespace UnityCore
{
    namespace Scene
    {
        public enum SceneType
        {
          None,
          Menu,
          Benton00,
          Benton01,
          Benton02,
          EndScene
        }

    }
}
