﻿using UnityCore.Menu;
using UnityEngine;
namespace UnityCore
{
    namespace Scene
    {
        public class Scene_Tester : MonoBehaviour
        {
            public SceneController sceneController;

            void Update()
            {
               if (Input.GetKeyUp(KeyCode.M))
               {
                   sceneController.Load(SceneType.Menu, _scene => {
                   Debug.Log("Scene [" + _scene + "] loaded from test scripts");
                   }, false, PageType.Loading);
               }

                if (Input.GetKeyUp(KeyCode.R))
                {
                    sceneController.Load(SceneType.Benton00);

                }
            }

        }
    }

}

