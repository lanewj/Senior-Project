﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace UnityCore
{
    namespace Menu
    {

        public class Menu_Tester : MonoBehaviour
        {
            public PageController pageController;

            private void Update()
            {

                if (Input.GetKeyUp(KeyCode.Space))
                {
                    pageController.TurnPageOn(PageType.Menu);
                }
                if (Input.GetKeyUp(KeyCode.G))
                {
                    pageController.TurnPageOff(PageType.Menu);
                }
                if (Input.GetKeyUp(KeyCode.H))
                {
                    pageController.TurnPageOff(PageType.Menu, PageType.Loading);
                }
                if (Input.GetKeyUp(KeyCode.J))
                {
                    pageController.TurnPageOff(PageType.Loading, PageType.Menu);

                }




            }

        }
    }
}
