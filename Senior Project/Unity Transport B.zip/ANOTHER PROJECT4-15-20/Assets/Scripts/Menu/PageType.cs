﻿namespace UnityCore
{
    namespace Menu
    {
        public enum PageType
        {
            None,
            Loading,
            Menu,
            end
        }
    }
}
